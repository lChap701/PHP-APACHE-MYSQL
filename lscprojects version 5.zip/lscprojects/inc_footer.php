<!-- PHP generated code -->
<?php
	/* Created by Lucas Chapman 6/9/2020 */
	/* This PHP file demonstrates the include statement */
	echo "<footer>&copy; Copyright 2020 Lucas Chapman</footer>"; 
?>